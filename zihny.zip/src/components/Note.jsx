import React from "react";

function Note() {
  return (
    <div className="note">
      <h1>JavaScrpit and ReactJs</h1>
      <p>
        This was an amazing bootcamp , learned lot of things . Thanks to Shaurya
        sinha for this intiative. They teach everything from scratch and starts
        from basics.
      </p>
    </div>
  );
}

export default Note;
