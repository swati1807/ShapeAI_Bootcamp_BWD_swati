import React from "react";

function Header()
{
  return(
  <div>
  <header><h1> Welcome to ShapeAI </h1></header>
  </div>
  );

}

export default Header;